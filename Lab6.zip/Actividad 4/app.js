+/*
1
Al hacer click en #btnClick, cambia el texto de #titulo a "Click detectado".

2
Al hacer doble click en #btnDoble, cambia el color de fondo de #caja a verde.

3
Al hacer clic derecho (contextmenu) en #btnContext, muestra un alert("Menú contextual bloqueado") y evita el menú.

4
Cuando el mouse entra en #caja (mouseover), agrega la clase .resaltado.

5
Cuando el mouse sale de #caja (mouseout), quita la clase .resaltado.

6
Cuando se presione una tecla (keydown), mostrar en consola la tecla presionada.

7
En el campo #nombre, contar caracteres en vivo con el evento input y mostrarlos en #contador.

8
En el campo #correo, al perder el foco (blur), mostrar un alert si está vacío.

9
En el formulario, al enviar (submit), prevenir el envío y mostrar un mensaje "Formulario enviado con éxito".

10
Detectar cuando la ventana cambia de tamaño (resize) y mostrar en consola el ancho actual.

*/

// app.js
document.addEventListener("DOMContentLoaded", () => {

    const boton = document.getElementById("btnClick");
    boton.addEventListener("click", () => {
        const titulo = document.getElementById("titulo");
        titulo.innerText = "Click detectado";
    });
    const boton2 = document.getElementById("btnDoble");
    boton2.addEventListener("dblclick", () => {
        const caja = document.getElementById("caja");
        caja.style.backgroundColor = "green";
    });
    const botonDerecho = document.getElementById("btnContext");
    botonDerecho.addEventListener("contextmenu", (event) => {
        event.preventDefault();
        alert("Menú contextual bloqueado");
    });
    



    const caja = document.getElementById("caja");
    caja.addEventListener("mouseover", () => {
        caja.classList.add("resaltado");
    });
    caja.addEventListener("mouseout", () => {
        caja.classList.remove("resaltado");
    });
    document.addEventListener("keydown", (event) => {
        console.log(`Tecla presionada: ${event.key}`);
    });
    const campo = document.getElementById("nombre");
    const contador = document.getElementById("contador");
    campo.addEventListener("input", () => {
        contador.innerText = "Caracteres: " + campo.value.length;
    });
    const campoCorreo = document.getElementById("correo");
    campoCorreo.addEventListener("blur", () => {
        if (campoCorreo.value.trim() === "") {
            alert("El campo de correo está vacío");
        }
    });
    const botonSubmit = document.getElementById("formulario");
    botonSubmit.addEventListener("submit", (event) => {
        event.preventDefault();
        alert("Formulario enviado con éxito");
    });
    window.addEventListener("resize", () => {
        console.log(`Ancho actual: ${window.innerWidth}px`);
    });

});
