// app.js

document.addEventListener("DOMContentLoaded", () => {
    // 1) Cambiar texto (innerText)
    const titulo = document.getElementById("site-title");
    titulo.innerText = "Conferencia Web Costa Rica 2025";

    // 2) Insertar HTML (innerHTML) al final de #desc
    const descripcion = document.getElementById("desc");
    descripcion.innerHTML += '<strong> ¡Entradas limitadas!</strong>';

    // 3) Actualizar atributos de imagen (src + alt)
    const imagenHero = document.getElementById("hero-img");
    imagenHero.setAttribute("src","https://via.placeholder.com/640x200?text=NEW+HERO");    
    imagenHero.setAttribute("alt","Hero actualizado");

    // 4) Habilitar y destacar CTA (removeAttribute, classList, innerText)
    const boton = document.getElementById("cta");
    boton.removeAttribute("disabled");
    boton.classList.add("primary");
    boton.innerText = "¡Quiero registrarme!";

    // 5) Enlace externo seguro: leer href y set target+rel
    const enlace = document.getElementById("ext-link");
    console.log(enlace.getAttribute("href"));
    enlace.setAttribute("target","_blank");
    enlace.setAttribute("rel","noopener noreferrer");

    // 6) Resaltar tags específicos (CSS o Accesibilidad)
    const etiquetas = document.querySelectorAll("#tags .tag");
    etiquetas.forEach((tags) => {
        if(tags.innerText == "CSS" || tags.innerText === "Accesibilidad"){
            tags.classList.add("resaltado");
        }
    });

    // 7) Placeholder + required en email
    const email = document.getElementById("email");
    email.setAttribute("placeholder","tu@correo.com");
    email.setAttribute("required","");

    // 8) data-state activo en la card (efecto visual con CSS)
    const date = document.getElementById("speaker-card");
    date.setAttribute("data-state","active");

    // 9) Crear y anexar un badge a h2 (createElement + appendChild)
    const tarjeta = document.getElementById("speaker-card");
    const h2 = tarjeta.querySelector(".card-title");
    const span = document.createElement("span");
    span.classList.add("badge");
    span.innerText = "Nuevo";
    h2.appendChild(span);

    // 10) Cambiar logo (src + alt)
    const logo = document.getElementById("logo");
    logo.setAttribute("src","https://via.placeholder.com/60x60?text=TEC");
    logo.setAttribute("alt","Logo TEC");

    // 11) Quitar atributo title del h1 (removeAttribute)
    const titulo2 = document.getElementById("site-title");
    titulo2.removeAttribute("title");
});
